"""Independent NumPy GMM audit. Does not import any pydynpd implementation.

Builds calendar-aligned equations/instruments from saved primary input rows.
Uses derivatives of the country moment covariance for the Windmeijer
correction, with a finite-difference cross-check. Not Stata/R validation.
"""
from pathlib import Path
import json
import numpy as np
import pandas as pd
from scipy import linalg,stats

ROOT=Path(__file__).resolve().parents[2]
OUT=Path(__file__).parent
TERMS=json.loads((ROOT/'02_code/14_reconstruction_specification.json').read_text())['covariates']

def construct(outcome,lagmax,system):
    f=pd.read_csv(ROOT/f'01_data/processed/full_reconstruction_samples/{outcome}__all.csv')
    keep=[iso for iso,g in f.groupby('iso3') if any(t-1 in set(g.year) and t-2 in set(g.year) for t in g.year)]
    years=np.arange(1996,2021); n=len(keep); nd=23; nl=24 if system else 0
    qg=7*(lagmax-1); q=qg+23+(8 if system else 0); k=30+int(system)
    X=np.zeros((n,nd+nl,k)); Y=np.zeros((n,nd+nl)); Z=np.zeros((n,nd+nl,q)); masks=[]
    for i,iso in enumerate(keep):
        v=f[f.iso3.eq(iso)].set_index('year').reindex(years)[[outcome+'_AS',*TERMS]].to_numpy(float)
        d=np.vstack([np.full((1,7),np.nan),np.diff(v,axis=0)])
        td=np.eye(25)[:,2:]; dt=np.vstack([np.zeros((1,23)),np.diff(td,axis=0)])
        for t in range(2,25):
            row=t-2; Y[i,row]=d[t,0]; X[i,row,:7]=np.r_[d[t-1,0],d[t,1:]]
            X[i,row,7:30]=dt[t]
            for j in range(7):
                for h in range(2,lagmax+1):
                    if t>=h:Z[i,row,j*(lagmax-1)+h-2]=v[t-h,j]
            Z[i,row,qg:qg+23]=dt[t]
        if system:
            for t in range(1,25):
                row=nd+t-1; Y[i,row]=v[t,0]; X[i,row,:7]=np.r_[v[t-1,0],v[t,1:]]
                X[i,row,7:30]=td[t];X[i,row,-1]=1
                Z[i,row,qg:qg+23]=td[t]
                if t>=2:Z[i,row,qg+23:qg+30]=d[t-1]
                Z[i,row,-1]=1
        valid=np.isfinite(Y[i])&np.isfinite(X[i]).all(axis=1)
        X[i,~valid]=0;Y[i,~valid]=0;Z[i,~valid]=0
        Z[i]=np.nan_to_num(Z[i]);masks.append(valid)
    # Initial error covariance from the equation transformation, not package H1.
    D=np.zeros((nd+nl,25))
    for t in range(2,25):D[t-2,t]=1;D[t-2,t-1]=-1
    if system:D[nd:,1:]=np.eye(24)
    return X,Y,Z,D@D.T,np.array(masks),keep

def fit(X,Y,Z,H):
    n=len(X);A=np.einsum('ntq,ntk->qk',Z,X);b=np.einsum('ntq,nt->q',Z,Y)
    # Rescale instrument moments before inversion to avoid arbitrary unit effects.
    scale=np.sqrt(np.einsum('ntq,ntq->q',Z,Z));Z=Z/scale[None,None,:]
    A=A/scale[:,None];b=b/scale
    def solve(S):
        W=linalg.pinvh(S,rtol=1e-13)
        Q=A.T@W@A
        V=linalg.inv(Q)
        B=V@A.T@W
        return B@b,V,B,W
    S0=np.einsum('ntq,tu,nur->qr',Z,H,Z)
    b1,V0,B0,W0=solve(S0)
    def scores(beta):return np.einsum('ntq,nt->nq',Z,Y-X@beta)
    m1=scores(b1);S1=m1.T@m1
    b2,V2,B2,W2=solve(S1);u=Y-X@b2;m2=scores(b2)
    V1=B0@S1@B0.T
    # Recompute the weight from perturbed first-step coefficients. Hold A,b fixed.
    derivative=np.zeros((len(b1),len(b1)))
    for j in range(len(b1)):
        h=1e-5*max(1,abs(b1[j]));plus=b1.copy();minus=b1.copy();plus[j]+=h;minus[j]-=h
        sp=scores(plus);sm=scores(minus)
        derivative[:,j]=(solve(sp.T@sp)[0]-solve(sm.T@sm)[0])/(2*h)
    numerical_derivative=derivative.copy()
    country_A=np.einsum('ntq,ntk->nqk',Z,X)
    for j in range(len(b1)):
        dS=-(country_A[:,:,j].T@m1+m1.T@country_A[:,:,j])
        derivative[:,j]=-B2@dS@W2@m2.sum(0)
    V=V2+derivative@V2+V2@derivative.T+derivative@V1@derivative.T
    se=np.sqrt(np.diag(V));J=float(m2.sum(0)@W2@m2.sum(0))
    ar=[]
    for lag in [1,2]:
        ud=u[:,:23];xd=X[:,:23];lagged=np.zeros_like(ud);lagged[:,lag:]=ud[:,:-lag]
        c=np.sum(lagged*ud,axis=1);ex=np.einsum('nt,ntk->k',lagged,xd)
        denom=c@c-2*ex@B2@(m2.T@c)+ex@V@ex
        ar.append(float(c.sum()/np.sqrt(denom)))
    return b2,se,J,ar,{'rank_Z':int(np.linalg.matrix_rank(Z.reshape(-1,Z.shape[-1]))),
        'rank_weight':int(np.linalg.matrix_rank(S1)),'rank_XZ':int(np.linalg.matrix_rank(A)),
        'condition_scaled_weight':float(np.linalg.cond(S1)),
        'derivative_finite_difference_max_error':float(np.max(abs(derivative-numerical_derivative)))}

def main():
    stored=pd.read_csv(ROOT/'04_results/tables/declared_GMM/all_coefficients.csv')
    diag=pd.read_csv(ROOT/'04_results/tables/declared_GMM/all_diagnostics.csv')
    checks=[];coeffs=[]
    for outcome in ['MD','AD','DD']:
        for label,lag,system in [('system_lag2',2,True),('system_lag23',3,True),('difference_lag23',3,False)]:
            model=outcome+'__'+label;X,Y,Z,H,valid,countries=construct(outcome,lag,system)
            oldz=np.load(ROOT/'03_logs/GMM'/f'{model}_instrument_matrix.npz')['Z'].reshape(len(X),Z.shape[2],Z.shape[1]).transpose(0,2,1)
            zdiff=float(np.max(np.abs(Z-oldz)));assert zdiff<1e-12,(model,zdiff)
            beta,se,J,ar,extra=fit(X,Y,Z,H)
            old=stored[stored.model.eq(model)].reset_index(drop=True);d=diag[diag.model.eq(model)].iloc[0]
            row={'model':model,'N_diff':int(valid[:,:23].sum()),'N_level':int(valid[:,23:].sum()),
                'countries':len(X),'instruments':Z.shape[2],'parameters':X.shape[2],
                'instrument_max_difference':zdiff,'coefficient_max_difference':float(np.max(abs(beta-old.coefficient))),
                'corrected_SE_max_difference':float(np.max(abs(se-old.std_err))),
                'Hansen_stat_max_difference':float(abs(J-d.Hansen_statistic)),
                'AR1_z_difference':float(abs(ar[0]-d.AR1_z)),'AR2_z_difference':float(abs(ar[1]-d.AR2_z)),
                'Hansen_J_independent':J,'Hansen_p_independent':float(stats.chi2.sf(J,Z.shape[2]-X.shape[2])),**extra}
            for i,r in old.iterrows():coeffs.append({'model':model,'variable':r.variable,'coefficient_independent':beta[i],
                'SE_independent':se[i],'p_independent':2*stats.norm.sf(abs(beta[i]/se[i]))})
            assert row['coefficient_max_difference']<1e-7
            assert row['corrected_SE_max_difference']<1e-7
            assert row['Hansen_stat_max_difference']<1e-7
            assert max(row['AR1_z_difference'],row['AR2_z_difference'])<1e-7
            checks.append(row);print(json.dumps(row),flush=True)
    pd.DataFrame(checks).to_csv(OUT/'GMM_independent_moment_checks.csv',index=False)
    pd.DataFrame(coeffs).to_csv(OUT/'GMM_independent_coefficients.csv',index=False)
    (OUT/'GMM_independent_scope.json').write_text(json.dumps({'implementation':'Standalone NumPy/SciPy; no pydynpd imports or estimator calls',
        'verified':'Calendar lags and Z from input rows; one/two-step coefficient algebra; moment-derivative Windmeijer covariance with finite-difference check; Hansen and AR statistics',
        'not_verified':'Not an independent Stata/R implementation; does not establish exogeneity, strength or mean stationarity; no Difference-in-Hansen test claimed',
        'references':['https://doi.org/10.1016/j.jeconom.2004.02.005','https://doi.org/10.21105/joss.04416']},indent=2),encoding='utf-8')

if __name__=='__main__':main()
