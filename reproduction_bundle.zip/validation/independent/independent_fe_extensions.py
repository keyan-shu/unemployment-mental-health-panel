"""Independent FWL, manual sandwich, contrasts, BH and influence diagnostics."""
from pathlib import Path
import json
import numpy as np
import pandas as pd
import openpyxl
from scipy import linalg,stats

ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).parent
T=json.loads((ROOT/'02_code/14_reconstruction_specification.json').read_text())['covariates']
P=pd.read_csv(ROOT/'01_data/processed/full_reconstruction_panel_GBD2021_ICRG2024.csv')
RESULT=ROOT/'04_results/tables/full_reconstruction'

def residualize(f,values,groupyear=False):
    country=pd.get_dummies(f.iso3,dtype=float).to_numpy()
    time=f.income_group+'_'+f.year.astype(str) if groupyear else f.year
    years=pd.get_dummies(time,dtype=float).to_numpy()
    D=np.column_stack([country,years])
    # Orthogonal projection handles the deliberately redundant dummy columns.
    U,s,_=linalg.svd(D,full_matrices=False)
    rank=int(np.sum(s>s[0]*1e-10));Q=U[:,:rank]
    return values-Q@(Q.T@values),rank

def fit(f,y,terms,groupyear=False):
    f=f.dropna(subset=[y,*terms]).copy()
    f=f[f.iso3.map(f.groupby('iso3').size()).ge(2)].reset_index(drop=True)
    r,rank=residualize(f,f[[y,*terms]].to_numpy(float),groupyear)
    X=r[:,1:];Y=r[:,0];b=linalg.lstsq(X,Y)[0];u=Y-X@b;bread=linalg.inv(X.T@X)
    g=f.iso3.nunique();n=len(f);K=rank+len(terms)
    scores=pd.DataFrame(X*u[:,None]).groupby(f.iso3).sum().to_numpy()
    V=bread@scores.T@scores@bread*g/(g-1)*(n-1)/(n-K)
    se=np.sqrt(np.diag(V));p=2*stats.t.sf(abs(b/se),g-1)
    return f,b,V,p,X,u,bread,K

def bh(p):
    p=np.array(p);idx=np.argsort(p);q=np.minimum.accumulate((p[idx]*len(p)/np.arange(1,len(p)+1))[::-1])[::-1]
    out=np.empty(len(p));out[idx]=np.minimum(q,1);return out

def main():
    rows=[]
    history=list(openpyxl.load_workbook(ROOT/'01_data/raw/wdi/historical_income_classification.xlsx',read_only=True,data_only=True)['Country Analytical History'].values)
    lookup={(r[0],year):r[j] for r in history[6:] if r[0] for j,year in enumerate(history[5]) if isinstance(year,int)}
    P['varying']=pd.Series([lookup.get((r.iso3,r.year)) for r in P.itertuples()]).map({'H':'high','UM':'middle','LM':'middle','L':'low'})
    for code,name in [('NY.GDP.PCAP.KD','level'),('SH.XPD.CHEX.GD.ZS','health')]:
        records=json.loads((ROOT/f'01_data/raw/wdi/{code}_1996_2020.json').read_text(encoding='utf-8'))[1]
        lu={(r['countryiso3code'],int(r['date'])):r['value'] for r in records}
        P[name]=[lu.get((r.iso3,r.year)) for r in P.itertuples()]
    P['log_GDPPC_level']=np.log(P.level.where(P.level.gt(0)));P['health_expenditure_GDP']=P.health
    jobs=[]
    for outcome in ['MD','AD','DD']:
        for group in ['all','high','middle','low']:
            jobs.append(('income_timevarying_sensitivity.csv',outcome+'__timevarying_'+group,
                P if group=='all' else P[P.varying.eq(group)],outcome+'_AS',T))
        base=pd.read_csv(ROOT/f'01_data/processed/full_reconstruction_samples/{outcome}__all.csv')
        for label,f,y,terms in [('all_ages',P,outcome+'_AA',T),('pre_COVID',P[P.year.le(2019)],outcome+'_AS',T),
            ('exclude_ICRG_A_flags',P[~P.ICRG_A_subcomponent_discrepancy],outcome+'_AS',T),
            ('omit_INST_same_sample',base,outcome+'_AS',T[:-1])]:
            jobs.append(('declared_sensitivity_all_coefficients.csv',outcome+'__'+label,f,y,terms))
        ext=T+['log_GDPPC_level','health_expenditure_GDP'];f=P.dropna(subset=ext)
        for terms,label in [(ext,'extended_controls'),(T,'baseline_same_extended_sample')]:
            jobs.append(('additional_controls_and_matched_baseline.csv',outcome+'__'+label,f,outcome+'_AS',terms))
    for file,model,f,y,terms in jobs:
        f,b,V,p,*_=fit(f,y,terms);old=pd.read_csv(RESULT/file);old=old[old.model.eq(model)].set_index('term').loc[terms]
        row={'model':model,'N':len(f),'G':f.iso3.nunique(),'max_b_diff':max(abs(b-old.coefficient)),
             'max_SE_diff':max(abs(np.sqrt(np.diag(V))-old.cluster_SE)),'max_p_diff':max(abs(p-old.p))}
        assert max(row[k] for k in ['max_b_diff','max_SE_diff','max_p_diff'])<1e-7,row
        rows.append(row)
    pd.DataFrame(rows).to_csv(OUT/'FE_sensitivity_independent_checks.csv',index=False)
    joints=[];pairs=[]
    for y in ['MD','AD','DD']:
        f=P.dropna(subset=['income_group']).copy();terms=[]
        for g in ['high','middle','low']:
            for t in T:
                name=g+'__'+t;terms.append(name);f[name]=f[t]*f.income_group.eq(g)
        f,b,V,p,*_=fit(f,y+'_AS',terms,True)
        for term in [T[0],T[-1]]:
            R=np.zeros((2,18))
            for i,g in enumerate(['middle','low']):R[i,terms.index(g+'__'+term)]=1;R[i,terms.index('high__'+term)]=-1
            effect=R@b;F=float(effect@linalg.solve(R@V@R.T,effect)/2);pv=stats.f.sf(F,2,f.iso3.nunique()-1)
            joints.append({'outcome':y,'term':term,'F':F,'p':pv})
            for label,r in [('middle-high',R[0]),('low-high',R[1]),('low-middle',R[1]-R[0])]:
                diff=r@b;se=np.sqrt(r@V@r);pairs.append({'outcome':y,'term':term,'contrast':label,'difference':diff,'SE':se,'p':2*stats.t.sf(abs(diff/se),f.iso3.nunique()-1)})
    for records,file,keys in [(joints,'income_heterogeneity_joint_tests.csv',['outcome','term']),
                              (pairs,'income_heterogeneity_pairwise.csv',['outcome','term','contrast'])]:
        a=pd.DataFrame(records);old=pd.read_csv(RESULT/file);m=a.merge(old,on=keys,suffixes=('_new','_old'))
        cols=['F','p'] if records is joints else ['difference','SE','p']
        assert max(float(max(abs(m[c+'_new']-m[c+'_old']))) for c in cols)<1e-7
        a.to_csv(OUT/('independent_'+file),index=False)
    old=pd.read_csv(RESULT/'income_heterogeneity_joint_tests.csv')
    assert np.allclose(bh([r['p'] for r in joints]),old.q_BH_6,atol=1e-10)
    primary=pd.read_csv(RESULT/'primary_FE_all72_coefficients.csv')
    for term,col in [(T[0],'q_BH_UN12'),(T[-1],'q_BH_INST12')]:
        a=primary[primary.term.eq(term)];assert np.allclose(bh(a.p),a[col],atol=1e-12)
    dk=[];vif=[]
    for y in ['MD','AD','DD']:
        f,b,V,p,X,u,bread,K=fit(P,y+'_AS',T)
        year_scores=pd.DataFrame(X*u[:,None]).groupby(f.year).sum().to_numpy();S=year_scores.T@year_scores
        for lag in [1,2]:
            cross=year_scores[lag:].T@year_scores[:-lag];S+=(1-lag/3)*(cross+cross.T)
        Vdk=bread@S@bread*25/24*(len(f)-1)/(len(f)-K);se=np.sqrt(np.diag(Vdk))
        old=pd.read_csv(RESULT/'Driscoll_Kraay_lag2_sensitivity.csv');old=old[old.outcome.eq(y)].set_index('term').loc[T]
        assert max(abs(se-old.SE_DK_lag2))<1e-8
        dk.append({'outcome':y,'max_SE_difference':float(max(abs(se-old.SE_DK_lag2)))})
        inv=linalg.inv(np.corrcoef(X,rowvar=False))
        vif.extend({'outcome':y,'term':t,'within_VIF':inv[i,i]} for i,t in enumerate(T))
    pd.DataFrame(dk).to_csv(OUT/'DK_independent_checks.csv',index=False)
    pd.DataFrame(vif).to_csv(OUT/'within_covariate_VIF.csv',index=False)
    # Influence is diagnostic only. Every country/year deletion is retained.
    base=P.dropna(subset=['MD_AS','AD_AS','DD_AS',*T]);base=base[base.iso3.map(base.groupby('iso3').size()).ge(2)]
    influence=[]
    for mode,values in [('country',sorted(base.iso3.unique())),('year',sorted(base.year.unique()))]:
        for value in values:
            f=base[base.iso3.ne(value)] if mode=='country' else base[base.year.ne(value)]
            f=f[f.iso3.map(f.groupby('iso3').size()).ge(2)].reset_index(drop=True)
            c=pd.factorize(f.iso3)[0];t=pd.factorize(f.year)[0];nc=c.max()+1;nt=t.max()+1
            a=f[[*T,'MD_AS','AD_AS','DD_AS']].to_numpy(float)
            for _ in range(200):
                old=a.copy()
                for ids,num in [(c,nc),(t,nt)]:
                    sums=np.zeros((num,9));np.add.at(sums,ids,a);a-= (sums/np.bincount(ids)[:,None])[ids]
                if abs(a-old).max()<1e-11:break
            else:raise AssertionError('Demeaning did not converge')
            X=a[:,:6];Y=a[:,6:];bread=linalg.inv(X.T@X);b=bread@X.T@Y;u=Y-X@b
            K=nc+nt-1+6
            for j,y in enumerate(['MD','AD','DD']):
                scores=np.zeros((nc,6));np.add.at(scores,c,X*u[:,j,None]);V=bread@scores.T@scores@bread*nc/(nc-1)*(len(f)-1)/(len(f)-K)
                se=np.sqrt(V[0,0]);influence.append({'deletion':mode,'excluded':value,'outcome':y,'N':len(f),'G':nc,
                    'UN_coefficient':b[0,j],'UN_SE':se,'UN_p':2*stats.t.sf(abs(b[0,j]/se),nc-1)})
    pd.DataFrame(influence).to_csv(OUT/'leave_one_country_or_year_out.csv',index=False)
    print(json.dumps({'sensitivity_models_verified':len(rows),'joint_tests':6,'pairwise_tests':18,'BH_families':3,
        'DK_models':3,'influence_models':len(influence),'all_checks_passed':True}),flush=True)

if __name__=='__main__':main()
