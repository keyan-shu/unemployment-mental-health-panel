"""Compare regenerated analytical tables with the audited published references."""
from pathlib import Path
import json
import numpy as np
import pandas as pd

ROOT=Path(__file__).resolve().parents[1]
checks=[]
for expected in sorted((ROOT/'derived_results').glob('*/*.csv')):
    if expected.name=='primary_fit_verification.csv':continue
    actual=ROOT/'04_results/tables'/expected.relative_to(ROOT/'derived_results')
    assert actual.is_file(),f'Missing regenerated output: {actual}'
    a=pd.read_csv(actual);b=pd.read_csv(expected)
    assert a.shape==b.shape and list(a.columns)==list(b.columns),expected.name
    delta=0.0
    for col in b:
        if pd.api.types.is_numeric_dtype(b[col]) and pd.api.types.is_numeric_dtype(a[col]):
            x=a[col].to_numpy(float);y=b[col].to_numpy(float)
            assert np.allclose(x,y,rtol=1e-6,atol=1e-8,equal_nan=True),(expected.name,col)
            finite=np.isfinite(x)&np.isfinite(y)
            if finite.any():delta=max(delta,float(np.max(abs(x[finite]-y[finite]))))
        else:
            assert a[col].fillna('<NA>').astype(str).equals(b[col].fillna('<NA>').astype(str)),(expected.name,col)
    checks.append({'file':expected.relative_to(ROOT).as_posix(),'rows':len(b),'max_numeric_difference':delta})
for expected in sorted((ROOT/'inclusion_keys').glob('*.csv')):
    actual=ROOT/'01_data/processed/full_reconstruction_samples'/expected.name
    a=pd.read_csv(actual,usecols=['iso3','year']).sort_values(['iso3','year']).reset_index(drop=True)
    b=pd.read_csv(expected).sort_values(['iso3','year']).reset_index(drop=True)
    assert a.equals(b),expected.name
report={'passed':True,'tables_checked':len(checks),'sample_key_files_checked':len(list((ROOT/'inclusion_keys').glob('*.csv'))),
        'relative_tolerance':1e-6,'absolute_tolerance':1e-8,'tables':checks}
(ROOT/'validation/reproduction_report.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
print(json.dumps({k:v for k,v in report.items() if k!='tables'},indent=2))
