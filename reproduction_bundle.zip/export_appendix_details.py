"""Export numerical evidence for Appendix Tables A7-A9 without Word dependencies."""
from pathlib import Path
import numpy as np
import pandas as pd
import importlib.util

ROOT=Path(__file__).resolve().parent
out=ROOT/'04_results/tables/panel_analysis'
sample=pd.read_csv(ROOT/'01_data/processed/panel_analysis_samples/MD__all.csv')
countries=sample.groupby(['iso3','country_wdi'],dropna=False).agg(income=('income_group','first'),N=('year','size'),first=('year','min'),last=('year','max')).reset_index()
countries['income']=countries.income.fillna('unclassified')
countries.to_csv(out/'primary_country_coverage.csv',index=False)
panel=pd.read_csv(ROOT/'01_data/processed/panel_analysis_panel_GBD2021_ICRG2024.csv')
panel=panel.loc[panel.mapped_to_GBD2021]
missing=[]
for iso,f in panel.groupby('iso3'):
    missing.append({'iso3':iso,**{c:int(f[c].isna().sum()) for c in ['UN_ilo_modelled','GLOB_kof2025','GDPPC_growth','URBAN','OSCHC_primary']},
                    'ICRG':int(f[['A','C','F','I','L']].isna().any(axis=1).sum())})
pd.DataFrame(missing).to_csv(out/'country_missing_years.csv',index=False)
spec=importlib.util.spec_from_file_location('fe',ROOT/'02_code/15_run_FE_models.py')
fe=importlib.util.module_from_spec(spec);spec.loader.exec_module(fe)
fits=[]
for outcome in ['MD','AD','DD']:
    for group in ['all','high','middle','low']:
        model=outcome+'__'+group
        f=pd.read_csv(ROOT/f'01_data/processed/panel_analysis_samples/{model}.csv')
        fit,f,rows=fe.estimate(f,outcome+'_AS',fe.TERMS,model)
        d=fe.design(f,fe.TERMS).drop(columns=fe.TERMS).to_numpy()
        y=f[outcome+'_AS'].to_numpy();r=y-d@np.linalg.lstsq(d,y,rcond=None)[0]
        fits.append({'model':model,'outcome':outcome,'group':group,'N':len(f),'countries':f.iso3.nunique(),
                     'years':f.year.nunique(),'parameters':int(fit.df_model+1),
                     'residual_df':int(fit.df_resid),'cluster_t_df':int(fit.df_resid_inference),
                     'overall_R2':float(fit.rsquared),'residualized_R2':float(1-np.sum(fit.resid**2)/np.sum(r**2))})
pd.DataFrame(fits).to_csv(out/'primary_model_fit.csv',index=False)
print('Exported Appendix A7-A9 evidence.')
