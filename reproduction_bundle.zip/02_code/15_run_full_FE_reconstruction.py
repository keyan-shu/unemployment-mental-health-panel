"""Run the fixed, fully logged FE reconstruction and declared reviewer sensitivities."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import numpy as np
import pandas as pd
import statsmodels.api as sm
from statsmodels.stats.multitest import multipletests

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'04_results/tables/full_reconstruction'
SAMPLES=ROOT/'01_data/processed/full_reconstruction_samples'
SPEC=json.loads((ROOT/'02_code/14_reconstruction_specification.json').read_text(encoding='utf-8'))
TERMS=SPEC['covariates']


def design(frame: pd.DataFrame, terms: list[str], group_year: bool=False) -> pd.DataFrame:
    time=frame.income_group+'_'+frame.year.astype(str) if group_year else frame.year.astype(str)
    return pd.concat([frame[terms].astype(float),pd.Series(1.,index=frame.index,name='intercept'),
                      pd.get_dummies(frame.iso3,prefix='country',drop_first=True,dtype=float),
                      pd.get_dummies(time,prefix='time',drop_first=True,dtype=float)],axis=1)


def estimate(frame: pd.DataFrame, outcome: str, terms: list[str], model: str, group_year: bool=False):
    frame=frame.dropna(subset=[outcome,*terms]).copy()
    counts=frame.groupby('iso3').size()
    frame=frame.loc[frame.iso3.isin(counts[counts>=2].index)].sort_values(['iso3','year']).reset_index(drop=True)
    x=design(frame,terms,group_year)
    # Group-specific year dummies include redundant group intercepts, absorbed by country FE.
    if group_year:
        time_cols=[c for c in x if c.startswith('time_')]
        for group in ['middle','low']:
            columns=[c for c in time_cols if c.startswith('time_'+group+'_')]
            if columns:x=x.drop(columns=columns[0])
    rank=np.linalg.matrix_rank(x.to_numpy())
    assert rank==x.shape[1],(model,rank,x.shape)
    g=frame.iso3.nunique()
    fit=sm.OLS(frame[outcome],x).fit(cov_type='cluster',cov_kwds={'groups':frame.iso3.to_numpy(),
        'use_correction':True,'df_correction':True},use_t=True)
    assert fit.df_resid_inference==g-1
    fe=x.drop(columns=terms).to_numpy();values=frame[[outcome,*terms]].to_numpy(float)
    residual=values-fe@np.linalg.lstsq(fe,values,rcond=None)[0]
    slopes=np.linalg.lstsq(residual[:,1:],residual[:,0],rcond=None)[0]
    error=float(np.max(np.abs(slopes-fit.params[terms].to_numpy())))
    assert error<1e-8,(model,error)
    ci=fit.conf_int();results=[]
    for term in terms:
        results.append({'model':model,'outcome':outcome,'term':term,'coefficient':float(fit.params[term]),
            'cluster_SE':float(fit.bse[term]),'CI95_lower':float(ci.loc[term,0]),'CI95_upper':float(ci.loc[term,1]),
            'p':float(fit.pvalues[term]),'N':len(frame),'countries':int(g),'year_min':int(frame.year.min()),
            'year_max':int(frame.year.max()),'t_df':int(g-1),'FWL_max_error':error})
    return fit,frame,results


def main() -> None:
    OUT.mkdir(parents=True,exist_ok=True);SAMPLES.mkdir(parents=True,exist_ok=True)
    path=ROOT/'01_data/processed/full_reconstruction_panel_GBD2021_ICRG2024.csv'
    panel=pd.read_csv(path)
    primary=[];flows=[];samples={}
    for outcome in SPEC['outcomes']:
        for group in SPEC['groups']:
            frame=panel if group=='all' else panel.loc[panel.income_group.eq(group)]
            model=f'{outcome}__{group}'
            fit,frame,rows=estimate(frame,outcome+'_AS',TERMS,model)
            for row in rows:row['group']=group
            primary.extend(rows);samples[(outcome,group)]=frame
            flows.append({'model':model,'starting_WDI_rows':len(panel if group=='all' else panel.loc[panel.income_group.eq(group)]),
                          'N':len(frame),'countries':frame.iso3.nunique(),
                          'income_missing_N':int(frame.income_group.isna().sum()),
                          'income_missing_countries':','.join(sorted(frame.loc[frame.income_group.isna(),'iso3'].unique()))})
            frame.to_csv(SAMPLES/(model+'.csv'),index=False,encoding='utf-8-sig')
            un=next(row for row in rows if row['term']=='UN_ilo_modelled')
            print(json.dumps({'model':model,'N':un['N'],'G':un['countries'],'UN':un['coefficient'],'p':un['p']}),flush=True)
    primary=pd.DataFrame(primary)
    for term,label in [('UN_ilo_modelled','UN12'),('INST_PC1_SD','INST12')]:
        mask=primary.term.eq(term);primary.loc[mask,'q_BH_'+label]=multipletests(primary.loc[mask,'p'],method='fdr_bh')[1]
    assert len(primary)==72
    primary.to_csv(OUT/'primary_FE_all72_coefficients.csv',index=False,encoding='utf-8-sig')
    pd.DataFrame(flows).to_csv(OUT/'primary_sample_flow.csv',index=False,encoding='utf-8-sig')
    # Formal income heterogeneity: group-specific slopes and year effects.
    contrasts=[];joints=[]
    for outcome in SPEC['outcomes']:
        frame=panel.dropna(subset=[outcome+'_AS',*TERMS,'income_group']).copy()
        interaction_terms=TERMS.copy()
        for group in ['middle','low']:
            for term in TERMS:
                label=term+'__'+group
                frame[label]=frame[term]*frame.income_group.eq(group).astype(float)
                interaction_terms.append(label)
        fit,frame,_=estimate(frame,outcome+'_AS',interaction_terms,outcome+'__interaction',True)
        for term in ['UN_ilo_modelled','INST_PC1_SD']:
            names=list(fit.params.index)
            r=np.zeros((2,len(names)))
            for i,group in enumerate(['middle','low']):r[i,names.index(term+'__'+group)]=1
            test=fit.wald_test(r,use_f=True,scalar=True)
            joints.append({'outcome':outcome,'term':term,'F':float(test.statistic),'df_num':2,
                           'df_den':frame.iso3.nunique()-1,'p':float(test.pvalue),
                           'N':len(frame),'countries':frame.iso3.nunique()})
            for label,vector in [('middle-high',r[0]),('low-high',r[1]),('low-middle',r[1]-r[0])]:
                test=fit.t_test(vector);ci=test.conf_int()[0]
                contrasts.append({'outcome':outcome,'term':term,'contrast':label,'difference':float(np.asarray(test.effect).item()),
                    'SE':float(np.asarray(test.sd).item()),'CI95_lower':float(ci[0]),'CI95_upper':float(ci[1]),'p':float(np.asarray(test.pvalue).item())})
        frame[['iso3','year','income_group']].to_csv(SAMPLES/(outcome+'__interaction_keys.csv'),index=False,encoding='utf-8-sig')
    joints=pd.DataFrame(joints);joints['q_BH_6']=multipletests(joints.p,method='fdr_bh')[1]
    joints.to_csv(OUT/'income_heterogeneity_joint_tests.csv',index=False,encoding='utf-8-sig')
    pd.DataFrame(contrasts).to_csv(OUT/'income_heterogeneity_pairwise.csv',index=False,encoding='utf-8-sig')
    sensitivity=[]
    for outcome in SPEC['outcomes']:
        base=samples[(outcome,'all')]
        for label,frame,y,terms in [
            ('all_ages',panel,outcome+'_AA',TERMS),
            ('pre_COVID',panel.loc[panel.year.le(2019)],outcome+'_AS',TERMS),
            ('exclude_ICRG_A_flags',panel.loc[~panel.ICRG_A_subcomponent_discrepancy],outcome+'_AS',TERMS),
            ('omit_INST_same_sample',base,outcome+'_AS',[t for t in TERMS if t!='INST_PC1_SD'])]:
            _,sample,rows=estimate(frame,y,terms,outcome+'__'+label)
            for row in rows:row['sensitivity']=label
            sensitivity.extend(rows)
            sample[['iso3','year']].to_csv(SAMPLES/(outcome+'__'+label+'_keys.csv'),index=False,encoding='utf-8-sig')
    pd.DataFrame(sensitivity).to_csv(OUT/'declared_sensitivity_all_coefficients.csv',index=False,encoding='utf-8-sig')
    base=samples[('MD','all')]
    base[['MD_AS','AD_AS','DD_AS',*TERMS]].describe().T.to_csv(OUT/'descriptive_estimation_sample.csv',encoding='utf-8-sig')
    panel[['MD_AS','AD_AS','DD_AS','A','C','F','I','L',*TERMS[:-1]]].isna().sum().to_csv(OUT/'missingness_on_WDI_skeleton.csv',encoding='utf-8-sig')
    log={'timestamp_utc':datetime.now(timezone.utc).isoformat(),'primary_models':12,'primary_coefficients':len(primary),
         'sensitivity_models':12,'joint_heterogeneity_tests':len(joints),'pairwise_contrasts':len(contrasts),
         'max_primary_FWL_error':float(primary.FWL_max_error.max()),
         'UN_negative_models':primary.loc[primary.term.eq('UN_ilo_modelled')&primary.coefficient.lt(0),'model'].tolist(),
         'UN_p_ge_05_models':primary.loc[primary.term.eq('UN_ilo_modelled')&primary.p.ge(.05),'model'].tolist(),
         'data_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),
         'spec_sha256':hashlib.sha256((ROOT/'02_code/14_reconstruction_specification.json').read_bytes()).hexdigest(),
         'all_outputs_retained':True,'original_commands_recovered':False}
    (ROOT/'03_logs/full_FE_reconstruction_run.json').write_text(json.dumps(log,ensure_ascii=False,indent=2),encoding='utf-8')


if __name__=='__main__':main()
