"""Audit the user-provided GBD export without fitting or selecting models."""
from pathlib import Path
import hashlib
import json
import shutil
import zipfile

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]


def main() -> None:
    source = ROOT / '01_data/IHME-GBD_2021_DATA-a719e539-1.zip'
    raw = ROOT / '01_data/raw/gbd2021'
    raw.mkdir(parents=True, exist_ok=True)
    archived = raw / source.name
    if archived.exists():
        assert archived.read_bytes() == source.read_bytes(), 'Archive differs from supplied ZIP'
    else:
        shutil.copy2(source, archived)
    with zipfile.ZipFile(source) as archive:
        assert archive.testzip() is None, 'ZIP CRC failure'
        csv_names = [n for n in archive.namelist() if n.lower().endswith('.csv')]
        assert len(csv_names) == 1
        csv_name = csv_names[0]
        csv_path = raw / Path(csv_name).name
        csv_path.write_bytes(archive.read(csv_name))
        (raw / 'citation.txt').write_bytes(archive.read('citation.txt'))
    data = pd.read_csv(csv_path)
    keys = ['population_group_id', 'measure_id', 'location_id', 'sex_id',
            'age_id', 'cause_id', 'metric_id', 'year']
    pairs = [('population_group_id', 'population_group_name'),
             ('measure_id', 'measure_name'), ('sex_id', 'sex_name'),
             ('age_id', 'age_name'), ('cause_id', 'cause_name'),
             ('metric_id', 'metric_name')]
    dimensions = {a: data[[a, b]].drop_duplicates().to_dict('records') for a, b in pairs}
    numeric = data[['val', 'lower', 'upper']].to_numpy()
    duplicate_count = int(data.duplicated(keys).sum())
    invalid_interval_count = int((~((data.lower <= data.val) & (data.val <= data.upper))).sum())
    expected = pd.MultiIndex.from_product(
        [sorted(data.location_id.unique()), range(1996, 2021),
         sorted(data.cause_id.unique()), [22, 27]],
        names=['location_id', 'year', 'cause_id', 'age_id'])
    actual = pd.MultiIndex.from_frame(data[expected.names])
    missing = expected.difference(actual)
    unexpected = actual.difference(expected)
    core = data.loc[data.cause_id.isin([558, 567, 571])].copy()
    # GBD Rate is cases per 100,000; retain original scale and add explicit percent columns.
    for column in ['val', 'lower', 'upper']:
        core[column + '_percent'] = core[column] / 1000
    core['outcome'] = core.cause_id.map({558: 'MD', 567: 'DD', 571: 'AD'})
    core.to_csv(ROOT / '01_data/interim/GBD2021_core_outcomes_both_ages_separate.csv',
                index=False, encoding='utf-8-sig')
    summary = data.groupby(['cause_id', 'cause_name', 'age_id', 'age_name']).agg(
        rows=('val', 'size'), locations=('location_id', 'nunique'),
        years=('year', 'nunique'), min_rate=('val', 'min'),
        max_rate=('val', 'max'), mean_rate=('val', 'mean')).reset_index()
    out = ROOT / '04_results/tables/GBD2021_audit'
    out.mkdir(parents=True, exist_ok=True)
    summary.to_csv(out / 'coverage_and_ranges.csv', index=False, encoding='utf-8-sig')
    data[['location_id', 'location_name']].drop_duplicates().sort_values('location_id').to_csv(
        out / 'locations.csv', index=False, encoding='utf-8-sig')
    report = {
        'audit_date': '2026-10-15', 'source': str(source),
        'sha256': hashlib.sha256(source.read_bytes()).hexdigest(),
        'zip_crc_passed': True, 'rows': len(data), 'dimensions': dimensions,
        'locations': int(data.location_id.nunique()), 'years': sorted(data.year.unique().tolist()),
        'expected_grid_rows': len(expected), 'missing_grid_cells': len(missing),
        'unexpected_grid_cells': len(unexpected), 'duplicate_keys': duplicate_count,
        'missing_cells': int(data.isna().sum().sum()),
        'nonfinite_numeric_cells': int((~np.isfinite(numeric)).sum()),
        'invalid_intervals': invalid_interval_count,
        'out_of_range_numeric_cells': int(((numeric < 0) | (numeric > 100000)).sum()),
        'core_rows': len(core), 'core_causes': {'MD': 558, 'DD': 567, 'AD': 571},
        'age_groups_kept_separate': True, 'country_ISO_mapping_completed': False,
        'INST_available': False, 'models_fitted': False,
        'notes': ['No disorders were summed: parent and child causes overlap.',
                  'Names are Chinese; IDs are retained as stable keys.',
                  'GBD2021 is a declared new source, not proven original vintage.',
                  'citation.txt is retained verbatim; its 2022 year requires bibliographic verification.'],
    }
    (ROOT / '03_logs/GBD2021_download_audit.json').write_text(
        json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
    assert duplicate_count == 0 and len(missing) == 0 and len(unexpected) == 0
    assert np.isfinite(numeric).all() and invalid_interval_count == 0
    assert set(data.measure_id) == {5} and set(data.sex_id) == {3}
    assert set(data.metric_id) == {3} and set(data.population_group_id) == {1}
    assert set(data.age_id) == {22, 27} and len(core) == 30600
    print(json.dumps({k: v for k, v in report.items() if k != 'dimensions'}, ensure_ascii=True, indent=2))


if __name__ == '__main__':
    main()
