"""Run nine explicitly declared exploratory dynamic GMM models, retaining all outputs."""
from pathlib import Path
import contextlib
from dataclasses import asdict
import hashlib
import json
import sys
import warnings
import traceback

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'02_code/vendor'))
import numpy as np
import pandas as pd
from pydynpd import regression


def main() -> None:
    specpath=ROOT/'02_code/16_GMM_specification.json'
    spec=json.loads(specpath.read_text(encoding='utf-8'))
    terms=json.loads((ROOT/'02_code/14_analysis_specification.json').read_text(encoding='utf-8'))['covariates']
    out=ROOT/'04_results/tables/declared_GMM';out.mkdir(exist_ok=True)
    logs=ROOT/'03_logs/GMM';logs.mkdir(exist_ok=True)
    diagnostics=[];coefficients=[];errors=[]
    for outcome in ['MD','AD','DD']:
        frame=pd.read_csv(ROOT/f'01_data/processed/panel_analysis_samples/{outcome}__all.csv')
        # A differenced equation with y(t-1) and lag-2 instruments needs a
        # genuinely consecutive three-year complete run. Zero-observation
        # countries must not inflate the estimator's country count.
        keep=[]
        for iso,group in frame.groupby('iso3'):
            years=set(group.year)
            if any(year-1 in years and year-2 in years for year in years):keep.append(iso)
        frame=frame.loc[frame.iso3.isin(keep)].copy()
        frame[['iso3','year']].to_csv(logs/(outcome+'_eligible_input_keys.csv'),index=False,encoding='utf-8-sig')
        frame['id']=pd.Categorical(frame.iso3).codes+1
        y=outcome+'_AS'
        for variant in spec['variants']:
            model=outcome+'__'+variant['label']
            lag=f"{variant['lag_min']}:{variant['lag_max']}"
            command=f"{y} L1.{y} {' '.join(terms)} | gmm({y} {' '.join(terms)}, {lag}) | collapse timedumm"
            if not variant['level']:command+=' nolevel'
            (logs/(model+'_command.txt')).write_text(command,encoding='utf-8')
            try:
                with (logs/(model+'_output.txt')).open('w',encoding='utf-8') as stream, contextlib.redirect_stdout(stream), contextlib.redirect_stderr(stream):
                    warnings.simplefilter('always')
                    result=regression.abond(command,frame,['id','year'])
                assert len(result.models)==1
                m=result.models[0]
                table=m.regression_table.copy();table['model']=model;table['outcome']=outcome
                table['CI95_lower']=table.coefficient-1.959963984540054*table.std_err
                table['CI95_upper']=table.coefficient+1.959963984540054*table.std_err
                coefficients.append(table)
                ar={a.lag:a for a in m.AR_list}
                row={'model':model,'outcome':outcome,'command':command,'N':int(m.num_obs),'countries':int(m.N),
                     'T':int(m.T),'min_obs_per_country':int(m.min_obs),'instruments':int(m.z_information.num_instr),
                     'Hansen_statistic':float(m.hansen.test_value),'Hansen_df':int(m.hansen.df),
                     'Hansen_p':float(m.hansen.p_value),
                     'AR1_z':float(ar[1].AR),'AR1_p':float(ar[1].P_value),
                     'AR2_z':float(ar[2].AR),'AR2_p':float(ar[2].P_value),
                     'instruments_less_than_countries':bool(m.z_information.num_instr<m.N)}
                row['Hansen_reject_05']=row['Hansen_p']<.05
                row['AR2_reject_05']=row['AR2_p']<.05
                diagnostics.append(row)
                np.savez_compressed(logs/(model+'_instrument_matrix.npz'),Z=m.z_list)
                (logs/(model+'_instrument_info.json')).write_text(json.dumps({k:int(v) for k,v in asdict(m.z_information).items()},indent=2),encoding='utf-8')
                print(json.dumps(row),flush=True)
            except (Exception,SystemExit) as exc:
                errors.append({'model':model,'command':command,'error':repr(exc)})
                (logs/(model+'_error.txt')).write_text(traceback.format_exc(),encoding='utf-8')
                print(json.dumps(errors[-1]),flush=True)
    pd.DataFrame(diagnostics).to_csv(out/'all_diagnostics.csv',index=False,encoding='utf-8-sig')
    if coefficients:pd.concat(coefficients,ignore_index=True).to_csv(out/'all_coefficients.csv',index=False,encoding='utf-8-sig')
    log={'spec_sha256':hashlib.sha256(specpath.read_bytes()).hexdigest(),'models_declared':9,
         'models_completed':len(diagnostics),'errors':errors,'all_outputs_retained':True,
         'software':'pydynpd 0.2.2','source':'https://github.com/dazhwu/pydynpd'}
    (ROOT/'03_logs/declared_GMM_run.json').write_text(json.dumps(log,ensure_ascii=False,indent=2),encoding='utf-8')


if __name__=='__main__':main()
