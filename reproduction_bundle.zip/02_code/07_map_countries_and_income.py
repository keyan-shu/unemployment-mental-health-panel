"""Make an explicit country crosswalk and candidate panel, with no regression."""
from pathlib import Path
from urllib.request import Request,urlopen
import hashlib
import json
import pandas as pd
import openpyxl

ROOT=Path(__file__).resolve().parents[1]
ALIASES={
 'Bahamas':'BHS','Bolivia (Plurinational State of)':'BOL','Congo':'COG',"Côte d'Ivoire":'CIV',
 "Democratic People's Republic of Korea":'PRK','Democratic Republic of the Congo':'COD',
 'Egypt':'EGY','Gambia':'GMB','Iran (Islamic Republic of)':'IRN','Kyrgyzstan':'KGZ',
 "Lao People's Democratic Republic":'LAO','Micronesia (Federated States of)':'FSM',
 'Nauru':'NRU','Palestine':'PSE','Puerto Rico':'PRI','Republic of Korea':'KOR',
 'Republic of Moldova':'MDA','Saint Kitts and Nevis':'KNA','Saint Lucia':'LCA',
 'Saint Vincent and the Grenadines':'VCT','Slovakia':'SVK','Somalia':'SOM',
 'Turkey':'TUR','United Republic of Tanzania':'TZA','United States Virgin Islands':'VIR',
 'United States of America':'USA','Venezuela (Bolivarian Republic of)':'VEN','Yemen':'YEM'}
AGGREGATES={'Africa','America','Asia','Europe','European Union','Global','World Bank High Income','World Bank Low Income',
            'World Bank Lower Middle Income','World Bank Upper Middle Income'}

def main():
    countries=pd.read_csv(ROOT/'01_data/interim/wdi_current_country_metadata.csv',keep_default_na=False)
    countries=countries.loc[~countries['aggregate']]
    direct=dict(zip(countries.country_wdi,countries.iso3)); valid=set(countries.iso3)
    data=pd.read_csv(ROOT/'01_data/interim/GBD2019_candidate_outcomes_both_ages_separate.csv')
    crosswalk=[]
    for name in sorted(data.location.unique()):
        iso=ALIASES.get(name,direct.get(name))
        if iso:
            assert iso in valid
        status='matched_explicit_alias' if name in ALIASES else 'matched_exact_name' if iso else 'excluded_aggregate' if name in AGGREGATES else 'unmatched_not_merged'
        crosswalk.append({'gbd_location':name,'iso3':iso,'status':status})
    crosswalk=pd.DataFrame(crosswalk)
    crosswalk.to_csv(ROOT/'01_data/interim/gbd2019_wdi_country_crosswalk.csv',index=False,encoding='utf-8-sig')
    data=data.merge(crosswalk,left_on='location',right_on='gbd_location',how='left',validate='many_to_one')
    data=data.loc[data.iso3.notna() & data.year.between(1996,2019)].copy()
    assert not data.duplicated(['iso3','year','age','variable']).any()
    wide=data.pivot(index=['iso3','year'],columns=['variable','age'],values='percent')
    wide.columns=[f'{variable}_GBD2019_'+('age_standardized' if age=='Age-standardized' else 'all_ages') for variable,age in wide.columns]
    wide=wide.reset_index()
    covariates=pd.read_csv(ROOT/'01_data/interim/candidate_covariates_1996_2020_no_imputation.csv')
    panel=covariates.merge(wide,on=['iso3','year'],how='left',validate='one_to_one')
    panel.sort_values(['iso3','year']).to_csv(ROOT/'01_data/processed/candidate_panel_GBD2019_WDI2026_KOF2025_no_INST.csv',index=False,encoding='utf-8-sig')
    # An official historical income workbook is archived for a later declared choice
    # between fixed and time-varying classifications. No income choice is made here.
    url='https://ddh-openapi.worldbank.org/resources/DR0095334/download'
    path=ROOT/'01_data/raw/wdi/historical_income_classification.xlsx'
    income={'url':url}
    try:
        if not path.exists():
            with urlopen(Request(url,headers={'User-Agent':'Country-panel-analysis/1.0'}),timeout=30) as r:content=r.read()
            assert content.startswith(b'PK')
            path.write_bytes(content)
        content=path.read_bytes()
        workbook=openpyxl.load_workbook(path,read_only=True,data_only=True)
        income.update(status='downloaded_or_cached',bytes=len(content),sha256=hashlib.sha256(content).hexdigest(),sheets=workbook.sheetnames)
    except Exception as exc:
        income.update(status='failed',error=str(exc))
    report={'matched_national_locations':int(crosswalk.iso3.notna().sum()),
            'unmatched_locations':crosswalk.loc[crosswalk.status.eq('unmatched_not_merged'),'gbd_location'].tolist(),
            'aggregate_locations_excluded':int(crosswalk.status.eq('excluded_aggregate').sum()),
            'panel_rows':len(panel),'panel_countries':int(panel.iso3.nunique()),
            'AD_DD_available_years':[1996,2019],
            'MD_available_same_GBD_version':False,'INST_available':False,
            'income_workbook':income,'models_fitted':False}
    (ROOT/'03_logs/country_mapping_and_income.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(report,ensure_ascii=True,indent=2))

if __name__=='__main__':
    main()
