"""Run income-classification, additional-control and covariance sensitivity analyses."""
from pathlib import Path
import importlib.util
import json
from urllib.request import Request,urlopen
import openpyxl
import numpy as np
import pandas as pd
import statsmodels.api as sm
from scipy.stats import t as t_distribution

ROOT=Path(__file__).resolve().parents[1]
module_spec=importlib.util.spec_from_file_location('fixed_fe',ROOT/'02_code/15_run_FE_models.py')
fe=importlib.util.module_from_spec(module_spec);module_spec.loader.exec_module(fe)


def main() -> None:
    out=ROOT/'04_results/tables/panel_analysis'
    panel=pd.read_csv(ROOT/'01_data/processed/panel_analysis_panel_GBD2021_ICRG2024.csv')
    sheet=openpyxl.load_workbook(ROOT/'01_data/raw/wdi/historical_income_classification.xlsx',read_only=True,data_only=True)['Country Analytical History']
    rows=list(sheet.iter_rows(values_only=True));refs=list(rows[5]);income={r[0]:r for r in rows[6:] if r[0]}
    panel['income_timevarying']=[income.get(iso,[None]*len(refs))[refs.index(year)] if year in refs else None for iso,year in zip(panel.iso3,panel.year)]
    panel['income_timevarying_group']=panel.income_timevarying.map({'H':'high','UM':'middle','LM':'middle','L':'low'})
    estimates=[]
    for outcome in ['MD','AD','DD']:
        for group in ['all','high','middle','low']:
            frame=panel if group=='all' else panel.loc[panel.income_timevarying_group.eq(group)]
            _,sample,results=fe.estimate(frame,outcome+'_AS',fe.TERMS,outcome+'__timevarying_'+group)
            estimates.extend(results)
    pd.DataFrame(estimates).to_csv(out/'income_timevarying_sensitivity.csv',index=False,encoding='utf-8-sig')
    downloads=[]
    for code,label in [('NY.GDP.PCAP.KD','GDPPC_level_real'),('SH.XPD.CHEX.GD.ZS','health_expenditure_GDP')]:
        path=ROOT/f'01_data/raw/wdi/{code}_1996_2020.json'
        url=f'https://api.worldbank.org/v2/country/all/indicator/{code}?date=1996:2020&format=json&per_page=20000'
        if not path.exists():
            with urlopen(Request(url,headers={'User-Agent':'Country panel analysis'}),timeout=45) as response:path.write_bytes(response.read())
        payload=json.loads(path.read_text(encoding='utf-8'));assert payload[0]['pages']==1
        data=pd.DataFrame([{'iso3':r['countryiso3code'],'year':int(r['date']),label:r['value']} for r in payload[1]])
        data=data.loc[data.iso3.isin(panel.iso3.unique())]
        assert not data.duplicated(['iso3','year']).any()
        panel=panel.merge(data,on=['iso3','year'],how='left',validate='one_to_one')
        downloads.append({'url':url,'label':label,'version':payload[0]['lastupdated']})
    panel['log_GDPPC_level']=np.log(panel.GDPPC_level_real.where(panel.GDPPC_level_real.gt(0)))
    extended_terms=fe.TERMS+['log_GDPPC_level','health_expenditure_GDP']
    estimates=[];hac=[]
    for outcome in ['MD','AD','DD']:
        sample=panel.dropna(subset=[outcome+'_AS',*extended_terms])
        for terms,label in [(extended_terms,'extended_controls'),(fe.TERMS,'baseline_same_extended_sample')]:
            _,used,results=fe.estimate(sample,outcome+'_AS',terms,outcome+'__'+label)
            estimates.extend(results)
        sample=pd.read_csv(ROOT/f'01_data/processed/panel_analysis_samples/{outcome}__all.csv')
        x=fe.design(sample,fe.TERMS)
        fit=sm.OLS(sample[outcome+'_AS'],x).fit(cov_type='hac-groupsum',cov_kwds={
            'time':(sample.year-sample.year.min()).to_numpy(),'maxlags':2,'use_correction':'cluster'},use_t=True)
        # DK relies on the time dimension; use T-1, not the package's inferred
        # country-block degrees of freedom on a country-sorted panel.
        df_time=int(sample.year.nunique()-1)
        critical=t_distribution.ppf(.975,df_time)
        for term in fe.TERMS:
            hac.append({'outcome':outcome,'term':term,'coefficient':fit.params[term],'SE_DK_lag2':fit.bse[term],
                        'CI95_lower':fit.params[term]-critical*fit.bse[term],
                        'CI95_upper':fit.params[term]+critical*fit.bse[term],
                        'p':2*t_distribution.sf(abs(fit.params[term]/fit.bse[term]),df_time),'t_df':df_time,
                        'N':len(sample),'countries':sample.iso3.nunique(),'time_periods':sample.year.nunique()})
    pd.DataFrame(estimates).to_csv(out/'additional_controls_and_matched_baseline.csv',index=False,encoding='utf-8-sig')
    pd.DataFrame(hac).to_csv(out/'Driscoll_Kraay_lag2_sensitivity.csv',index=False,encoding='utf-8-sig')
    (ROOT/'03_logs/sensitivity_analyses_run.json').write_text(json.dumps({'income_models':12,
        'extended_and_matched_models':6,'DK_covariance_models':3,'downloads':downloads,'all_retained':True},indent=2),encoding='utf-8')
    print('Completed 12 income, 6 control and 3 dependence sensitivity fits.')


if __name__=='__main__':main()
