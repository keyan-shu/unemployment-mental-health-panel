"""Archive candidate public sources; no candidate is asserted to be the original data."""
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
from pathlib import Path
from urllib.request import Request, urlopen
import hashlib
import json

ROOT = Path(__file__).resolve().parents[1]
RAW = ROOT / '01_data/raw'
JOBS = [
 ('reference_article/frontiers_1440403.html', 'https://www.frontiersin.org/journals/public-health/articles/10.3389/fpubh.2024.1440403/full', 'Published reference article; provenance investigation'),
 ('kof/KOFGI_2025_public.xlsx', 'https://ethz.ch/content/dam/ethz/special-interest/dual/kof-dam/documents/Globalization/2025/KOFGI_2025_public.xlsx', 'Candidate current vintage; original vintage unknown'),
 ('kof/KOFGI_2024.zip', 'https://ethz.ch/content/dam/ethz/special-interest/dual/kof-dam/documents/Globalization/2025/KOFGI_2024.zip', 'Candidate archive; original vintage unknown'),
 ('wdi/countries_current.json', 'https://api.worldbank.org/v2/country?format=json&per_page=400', 'Current country metadata; income groups must not be treated as historical'),
]
for code in ['SL.UEM.TOTL.ZS', 'SL.UEM.TOTL.NE.ZS', 'SP.URB.TOTL.IN.ZS', 'SE.PRM.UNER.ZS', 'NY.GDP.PCAP.KD.ZG']:
    JOBS.extend([
        (f'wdi/{code}_1996_2020.json', f'https://api.worldbank.org/v2/country/all/indicator/{code}?date=1996:2020&format=json&per_page=20000&source=2', 'Candidate series; original code unknown'),
        (f'wdi/{code}_metadata.json', f'https://api.worldbank.org/v2/indicator/{code}?format=json', 'Official indicator definition'),
    ])
for slug in ['share-with-mental-and-substance-disorders', 'depressive-disorders-prevalence-ihme', 'anxiety-disorders-prevalence']:
    for ext in ['csv', 'metadata.json']:
        JOBS.append((f'owid_current/{slug}.{ext}', f'https://ourworldindata.org/grapher/{slug}.{ext}', 'Current OWID/GBD candidate; original vintage and age metric unknown'))

def download(job):
    rel, url, role = job
    path = RAW / rel
    row = {'file': rel, 'url': url, 'role': role, 'timestamp_utc': datetime.now(timezone.utc).isoformat()}
    try:
        if path.exists() and path.stat().st_size:
            data = path.read_bytes()
            row['status'] = 'cached'
        else:
            req = Request(url, headers={'User-Agent': 'Research-reconstruction/1.0'})
            with urlopen(req, timeout=45) as response:
                data = response.read()
                row['content_type'] = response.headers.get('Content-Type')
                row['resolved_url'] = response.url
            if rel.endswith('.json'):
                json.loads(data)
            if rel.endswith(('.xlsx', '.zip')) and not data.startswith(b'PK'):
                raise ValueError('Expected ZIP/OOXML content')
            if rel.endswith('.csv') and b'<html' in data[:1000].lower():
                raise ValueError('HTML returned instead of CSV')
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes(data)
            row['status'] = 'downloaded'
        row.update(bytes=len(data), sha256=hashlib.sha256(data).hexdigest())
    except Exception as exc:
        row.update(status='failed', error=f'{type(exc).__name__}: {exc}')
    print(json.dumps({'file': rel, 'status': row['status'], 'bytes': row.get('bytes'), 'error': row.get('error')}, ensure_ascii=True), flush=True)
    return row

if __name__ == '__main__':
    for directory in ['01_data/interim', '01_data/processed', '03_logs', '04_results/tables']:
        (ROOT / directory).mkdir(parents=True, exist_ok=True)
    with ThreadPoolExecutor(max_workers=4) as pool:
        results = list(pool.map(download, JOBS))
    (ROOT / '03_logs/public_source_downloads.json').write_text(json.dumps(results, ensure_ascii=False, indent=2), encoding='utf-8')
