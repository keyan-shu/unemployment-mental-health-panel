"""Prepare version-labelled public covariates; no imputation and no model fitting."""
from pathlib import Path
import csv
import json
import zipfile
import io
import pandas as pd
import openpyxl

ROOT = Path(__file__).resolve().parents[1]

def main():
    for directory in ['01_data/interim', '01_data/processed', '04_results/tables', '03_logs']:
        (ROOT / directory).mkdir(parents=True, exist_ok=True)
    raw=ROOT/'01_data/raw'
    countries=json.loads((raw/'wdi/countries_current.json').read_text())[1]
    country_rows=[{'iso3':r['id'],'iso2':r['iso2Code'],'country_wdi':r['name'],
                   'region_id':r['region']['id'],'income_current':r['incomeLevel']['value'],
                   'aggregate':r['region']['id']=='NA'} for r in countries]
    country_table=pd.DataFrame(country_rows)
    country_table.to_csv(ROOT/'01_data/interim/wdi_current_country_metadata.csv',index=False,encoding='utf-8-sig')
    valid=set(country_table.loc[~country_table['aggregate'],'iso3'])
    definitions={
      'SL.UEM.TOTL.ZS':'UN_ilo_modelled',
      'SL.UEM.TOTL.NE.ZS':'UN_national',
      'SP.URB.TOTL.IN.ZS':'URBAN',
      'SE.PRM.UNER.ZS':'OSCHC_primary',
      'NY.GDP.PCAP.KD.ZG':'GDPPC_growth',
    }
    panel=None; coverage=[]
    for code,label in definitions.items():
        payload=json.loads((raw/f'wdi/{code}_1996_2020.json').read_text())
        assert payload[0]['pages']==1 and len(payload[1])==payload[0]['total']
        df=pd.DataFrame([{'iso3':r['countryiso3code'],'year':int(r['date']),label:r['value']} for r in payload[1]])
        dropped=len(df.loc[~df.iso3.isin(valid)])
        df=df.loc[df.iso3.isin(valid)].copy()
        assert not df.duplicated(['iso3','year']).any()
        assert df.year.between(1996,2020).all()
        coverage.append({'variable':label,'code':code,'source_vintage':payload[0]['lastupdated'],
                         'rows_country_year':len(df),'nonmissing':int(df[label].notna().sum()),
                         'missing':int(df[label].isna().sum()),'aggregate_or_unmapped_rows_removed':dropped})
        panel=df if panel is None else panel.merge(df,on=['iso3','year'],how='outer',validate='one_to_one')
    kofpath=raw/'kof/KOFGI_2025_public.xlsx'
    workbook=openpyxl.load_workbook(kofpath,read_only=True,data_only=True)
    sheet=workbook.active
    iterator=sheet.iter_rows(values_only=True); columns=next(iterator)
    kof=pd.DataFrame(iterator,columns=columns)
    kof=kof.loc[kof.year.between(1996,2020),['code','year','KOFGI','KOFGIdf','KOFGIdj']].rename(columns={'code':'iso3','KOFGI':'GLOB_kof2025','KOFGIdf':'GLOB_de_facto_kof2025','KOFGIdj':'GLOB_de_jure_kof2025'})
    assert not kof.duplicated(['iso3','year']).any()
    kof=kof.loc[kof.iso3.isin(valid)]
    panel=panel.merge(kof,on=['iso3','year'],how='left',validate='one_to_one')
    for variable in ['GLOB_kof2025','GLOB_de_facto_kof2025','GLOB_de_jure_kof2025']:
        coverage.append({'variable':variable,'code':variable,'source_vintage':'KOF2025',
                         'rows_country_year':len(panel),'nonmissing':int(panel[variable].notna().sum()),
                         'missing':int(panel[variable].isna().sum()),'aggregate_or_unmapped_rows_removed':None})
    panel=panel.merge(country_table.loc[~country_table['aggregate']],on='iso3',how='left',validate='many_to_one')
    panel.sort_values(['iso3','year']).to_csv(ROOT/'01_data/interim/candidate_covariates_1996_2020_no_imputation.csv',index=False,encoding='utf-8-sig')
    pd.DataFrame(coverage).to_csv(ROOT/'04_results/tables/candidate_covariate_coverage.csv',index=False,encoding='utf-8-sig')
    # Never use current income labels as the historical grouping in a regression.
    complete=panel[['UN_ilo_modelled','URBAN','OSCHC_primary','GDPPC_growth','GLOB_kof2025']].notna().all(axis=1)
    archive=raw/'kof/KOFGI_2024.zip'
    # The unused KOF2024 archive is optional acquisition metadata, not an input.
    archive_members=[]
    if archive.exists():
        with zipfile.ZipFile(archive) as z:
            archive_members=[{'name':i.filename,'bytes':i.file_size} for i in z.infolist()]
    report={'countries_in_candidate_skeleton':int(panel.iso3.nunique()),'rows':len(panel),
            'complete_on_five_covariates_excluding_INST':int(complete.sum()),
            'complete_countries_excluding_INST':int(panel.loc[complete,'iso3'].nunique()),
            'INST_available':False,'outcomes_in_panel':False,
            'imputation_performed':False,'models_fitted':False,
            'income_metadata':'Current labels support country mapping; historical workbook defines analytical income groups',
            'kof2024_archive_members':archive_members}
    (ROOT/'03_logs/candidate_covariate_preparation.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(report,ensure_ascii=True,indent=2))

if __name__=='__main__':
    main()
