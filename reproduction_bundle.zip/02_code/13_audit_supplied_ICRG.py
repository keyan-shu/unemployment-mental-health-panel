"""Read supplied legacy XLS files; audit the five declared ICRG inputs, no PCA/fit."""
from pathlib import Path
import hashlib
import json
import runpy
import shutil

import numpy as np
import pandas as pd
import xlrd

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / '01_data/sj200-ICRG数据库(1984-2023)'
COMPONENTS = {'A-Government Stability': 12, 'C-Investment Profile': 12,
              'F-Corruption': 6, 'I-Law and Order': 6, 'L-Bureaucracy Quality': 4}
HISTORICAL = {'Czechoslovakia', 'East Germany', 'West Germany', 'USSR', 'Serbia & Montenegro'}
EXTRA_ALIASES = {'Brunei': 'BRN', 'Congo, DR': 'COD', 'Czech Republic': 'CZE',
                 'Hong Kong': 'HKG', 'Iran': 'IRN', 'Korea, DPR': 'PRK',
                 'Russia': 'RUS', 'South Korea': 'KOR', 'Syria': 'SYR',
                 'Trinidad & Tobago': 'TTO', 'UAE': 'ARE', 'Venezuela': 'VEN', 'Vietnam': 'VNM'}


def read_component(sheet: xlrd.sheet.Sheet, column: str) -> pd.DataFrame:
    header = next(i for i in range(sheet.nrows) if str(sheet.cell_value(i, 0)).strip() == 'Country')
    rows = []
    for r in range(header + 1, sheet.nrows):
        raw_name = str(sheet.cell_value(r, 0))
        name = raw_name.strip().rstrip('*').strip()
        if not name:
            continue
        for c in range(1, sheet.ncols):
            year = sheet.cell_value(header, c)
            assert isinstance(year, (int, float)) and float(year).is_integer()
            value = sheet.cell_value(r, c)
            if isinstance(value, str) and not value.strip():
                value = np.nan
            elif not isinstance(value, (int, float)):
                raise ValueError(f'Unexpected cell: {sheet.name}, {raw_name}, {year}: {value!r}')
            rows.append({'country_icrg': name, 'country_label_raw': raw_name,
                         'year': int(year), column: value})
    frame = pd.DataFrame(rows)
    assert not frame.duplicated(['country_icrg', 'year']).any()
    return frame


def main() -> None:
    raw = ROOT / '01_data/raw/icrg_supplied'
    raw.mkdir(parents=True, exist_ok=True)
    manifest, inventory = [], []
    for source in sorted(SOURCE.glob('*.xls')):
        content = source.read_bytes()
        target = raw / source.name
        if target.exists():
            assert target.read_bytes() == content, 'Archived file differs'
        else:
            shutil.copy2(source, target)
        manifest.append({'file': str(source), 'sha256': hashlib.sha256(content).hexdigest(),
                         'bytes': len(content)})
        book = xlrd.open_workbook(source)
        inventory.append({'file': source.name, 'sheets': [
            {'name': sheet.name, 'rows': sheet.nrows, 'columns': sheet.ncols} for sheet in book.sheets()]})
    source = next(SOURCE.glob('3BResearchers*.xls'))
    book = xlrd.open_workbook(source)
    wide = None
    for sheet_name, maximum in COMPONENTS.items():
        column = sheet_name[0]
        frame = read_component(book.sheet_by_name(sheet_name), column)
        values = frame[column].dropna()
        assert np.isfinite(values).all() and values.between(0, maximum).all()
        if wide is None:
            wide = frame
        else:
            wide = wide.merge(frame.drop(columns='country_label_raw'),
                              on=['country_icrg', 'year'], validate='one_to_one')
    columns = [name[0] for name in COMPONENTS]
    assert wide is not None
    target = wide.loc[wide.year.between(1996, 2020)].copy()
    target['five_complete'] = target[columns].notna().all(axis=1)
    target.to_csv(ROOT / '01_data/interim/ICRG_five_components_1996_2020_all_entities.csv',
                  index=False, encoding='utf-8-sig')
    metadata = pd.read_csv(ROOT / '01_data/interim/wdi_current_country_metadata.csv', keep_default_na=False)
    metadata = metadata.loc[~metadata['aggregate']]
    direct = dict(zip(metadata.country_wdi, metadata.iso3))
    aliases = runpy.run_path(str(ROOT / '02_code/07_map_countries_and_income.py'))['ALIASES']
    aliases.update(EXTRA_ALIASES)
    crosswalk = []
    for name in sorted(target.country_icrg.unique()):
        iso = aliases.get(name, direct.get(name))
        status = ('historical_entity_not_spliced' if name in HISTORICAL else
                  'outside_WDI_country_list' if name == 'Taiwan' else
                  'matched_explicit_alias' if name in aliases else
                  'matched_exact_name' if iso else 'unresolved')
        if status in {'historical_entity_not_spliced', 'outside_WDI_country_list'}:
            iso = None
        crosswalk.append({'country_icrg': name, 'iso3': iso, 'status': status})
    crosswalk = pd.DataFrame(crosswalk)
    target = target.merge(crosswalk, on='country_icrg', validate='many_to_one')
    matched = target.loc[target.iso3.notna()].copy()
    assert not matched.duplicated(['iso3', 'year']).any()
    cov = pd.read_csv(ROOT / '01_data/interim/candidate_covariates_1996_2020_no_imputation.csv')
    panel = cov.merge(matched[['iso3', 'year', *columns]], on=['iso3', 'year'],
                      how='left', validate='one_to_one')
    panel.to_csv(ROOT / '01_data/processed/candidate_covariates_with_ICRG_five_no_PCA.csv',
                 index=False, encoding='utf-8-sig')
    output = ROOT / '04_results/tables/ICRG_supplied_audit'
    output.mkdir(parents=True, exist_ok=True)
    crosswalk.to_csv(output / 'ICRG_WDI_country_crosswalk.csv', index=False, encoding='utf-8-sig')
    missing = target.loc[~target.five_complete, ['country_icrg', 'year', *columns]]
    missing.to_csv(output / 'missing_country_years.csv', index=False, encoding='utf-8-sig')
    coverage = target.groupby('year').agg(country_entities=('country_icrg', 'size'),
                                         complete_five=('five_complete', 'sum')).reset_index()
    coverage.to_csv(output / 'coverage_by_year.csv', index=False, encoding='utf-8-sig')
    component_summary = [{'component': col, 'sheet': sheet, 'nonmissing': int(target[col].notna().sum()),
                          'missing': int(target[col].isna().sum()), 'min': float(target[col].min()),
                          'max': float(target[col].max())} for sheet, col in zip(COMPONENTS, columns)]
    pd.DataFrame(component_summary).to_csv(output / 'five_component_summary.csv', index=False, encoding='utf-8-sig')
    # Independent within-package check: A/C equal sums of their three subcomponents.
    sub_book = xlrd.open_workbook(next(SOURCE.glob('3BaResearchers*.xls')))
    internal_checks = []
    for parent, sheets in [('A', ['A1-Government Cohesion', 'A2-Legislative strength', 'A3-Popular Support']),
                           ('C', ['C1-Contract Viability', 'C2-Repatriation', 'C3-Payment Delays'])]:
        check = wide[['country_icrg', 'year', parent]].copy()
        for i, sheet in enumerate(sheets):
            sub = read_component(sub_book.sheet_by_name(sheet), f'sub{i}')
            check = check.merge(sub.drop(columns='country_label_raw'), on=['country_icrg', 'year'],
                                validate='one_to_one')
        check = check.loc[check.year.between(2002, 2020)].dropna()
        delta = check[parent] - check[['sub0', 'sub1', 'sub2']].sum(axis=1)
        check['parent_minus_sum'] = delta
        check.loc[delta.abs() > 1e-8].to_csv(output / f'{parent}_subcomponent_discrepancies.csv',
                                          index=False, encoding='utf-8-sig')
        internal_checks.append({'component': parent, 'years': [2002, 2020], 'pairs': len(check),
                                'max_abs_difference': float(delta.abs().max()),
                                'mismatches_above_1e_8': int((delta.abs() > 1e-8).sum())})
    required_cov = ['UN_ilo_modelled', 'GLOB_kof2025', 'GDPPC_growth', 'URBAN', 'OSCHC_primary']
    eligible = panel.dropna(subset=[*required_cov, *columns])
    report = {'date': '2026-10-15', 'manifest': manifest, 'inventory': inventory,
              'selected_file': str(source), 'all_five_components_present': True,
              'available_years': sorted(wide.year.unique().tolist()),
              'raw_country_entities': int(target.country_icrg.nunique()),
              'target_grid_rows': len(target), 'complete_five_country_years': int(target.five_complete.sum()),
              'entities_with_any_complete_five': int(target.loc[target.five_complete, 'country_icrg'].nunique()),
              'yearly_complete_min': int(coverage.complete_five.min()),
              'yearly_complete_max': int(coverage.complete_five.max()),
              'component_summary': component_summary,
              'missingness_pattern_same_across_five': bool(target[columns].isna().nunique(axis=1).eq(1).all()),
              'WDI_matched_entities': int(matched.iso3.nunique()),
              'WDI_matched_complete_five_rows': int(matched.five_complete.sum()),
              'WDI_matched_countries_with_complete_five': int(matched.loc[matched.five_complete, 'iso3'].nunique()),
              'complete_ICRG_and_five_covariates_rows_before_GBD_merge': len(eligible),
              'complete_ICRG_and_five_covariates_countries_before_GBD_merge': int(eligible.iso3.nunique()),
              'unresolved_names': crosswalk.loc[crosswalk.status.eq('unresolved'), 'country_icrg'].tolist(),
              'within_package_subcomponent_checks': internal_checks,
              'original_source_authenticity_independently_verified': False,
              'license_for_use_and_redistribution_verified': False,
              'copyright_sheet_present': True, 'PCA_fitted': False, 'models_fitted': False,
              'GBD2021_ID_merge_completed': False,
              'notes': ['Whitespace-only cells are missing; no zero filling or interpolation.',
                        'Only terminal asterisks/whitespace on country labels removed; original labels preserved.',
                        'Historical Serbia & Montenegro not spliced into modern Serbia.',
                        'Package includes non-data promotional files, which were not opened or followed.',
                        'Source data vintage and original PCA/GMM commands remain unknown.']}
    (ROOT / '03_logs/supplied_ICRG_audit.json').write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
    print(json.dumps({k: v for k, v in report.items() if k not in {'manifest', 'inventory', 'notes'}}, ensure_ascii=True, indent=2))


if __name__ == '__main__':
    main()
