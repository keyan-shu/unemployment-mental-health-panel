"""Build the five-component reconstruction and record PCA before outcome estimation."""
from pathlib import Path
import hashlib
import json
import xlrd
import openpyxl
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
# Explicit country identities for Chinese label variants in the supplied dictionary.
ID_BY_ISO = {'BHS':106,'BHR':140,'BOL':121,'BRN':66,'BFA':201,'COD':171,'CIV':205,
             'IDN':11,'IRN':142,'PRK':7,'LUX':87,'MLT':88,'MDA':61,'PNG':26,
             'KOR':68,'SYR':153,'TZA':189,'TTO':119,'TUR':155,'ARE':156,
             'GBR':95,'USA':102,'UZB':41,'VEN':133}


def main() -> None:
    specpath = ROOT/'02_code/14_reconstruction_specification.json'
    spec = json.loads(specpath.read_text(encoding='utf-8'))
    cov = pd.read_csv(ROOT/'01_data/processed/candidate_covariates_with_ICRG_five_no_PCA.csv')
    cross = pd.read_csv(ROOT/'04_results/tables/ICRG_supplied_audit/ICRG_WDI_country_crosswalk.csv').dropna(subset=['iso3'])
    source = next((ROOT/'01_data/sj200-ICRG数据库(1984-2023)').glob('指标*.xls'))
    sheet = xlrd.open_workbook(source).sheet_by_name('国名对照表')
    chinese = {str(sheet.cell_value(r,0)).strip():str(sheet.cell_value(r,1)).strip() for r in range(1,sheet.nrows)}
    gbd = pd.read_csv(ROOT/'01_data/interim/GBD2021_core_outcomes_both_ages_separate.csv')
    locations = gbd[['location_id','location_name']].drop_duplicates()
    id_from_name = dict(zip(locations.location_name,locations.location_id))
    mapping = []
    for row in cross.itertuples():
        location_id = ID_BY_ISO.get(row.iso3,id_from_name.get(chinese.get(row.country_icrg)))
        mapping.append({'iso3':row.iso3,'country_icrg':row.country_icrg,
                        'Chinese_dictionary_label':chinese.get(row.country_icrg),
                        'location_id':location_id,
                        'method':'explicit_country_identity' if row.iso3 in ID_BY_ISO else
                                 'exact_supplied_Chinese_name' if location_id else 'outside_GBD_national_list'})
    mapping = pd.DataFrame(mapping)
    absent = set(mapping.loc[mapping.location_id.isna(),'iso3'])
    assert absent == {'HKG','NCL'}, f'Unresolved countries: {absent}'
    mapped = mapping.dropna(subset=['location_id']).copy()
    mapped['location_id'] = mapped.location_id.astype(int)
    assert not mapped.location_id.duplicated().any() and not mapped.iso3.duplicated().any()
    gbd = gbd.merge(mapped[['location_id','iso3']],on='location_id',how='inner',validate='many_to_one')
    wide = gbd.pivot(index=['iso3','year'],columns=['outcome','age_id'],values='val_percent')
    wide.columns = [f'{outcome}_'+('AS' if age==27 else 'AA') for outcome,age in wide.columns]
    panel = cov.merge(wide.reset_index(),on=['iso3','year'],how='left',validate='one_to_one')
    panel['mapped_to_GBD2021'] = panel.iso3.isin(mapped.iso3)
    components = spec['PCA']['components']
    fitmask = panel.mapped_to_GBD2021 & panel[components].notna().all(axis=1)
    fitdata = panel.loc[fitmask,components].astype(float)
    mean, sd = fitdata.mean(), fitdata.std(ddof=1)
    z = (fitdata-mean)/sd
    corr = z.to_numpy().T@z.to_numpy()/(len(z)-1)
    eig, vec = np.linalg.eigh(corr)
    order = np.argsort(eig)[::-1];eig=eig[order];vec=vec[:,order]
    if vec[:,0].sum()<0: vec[:,0]*=-1
    score_sd = np.sqrt(eig[0])
    panel['INST_PC1_SD'] = np.nan
    panel.loc[fitmask,'INST_PC1_SD'] = z.to_numpy()@vec[:,0]/score_sd
    assert abs(panel.loc[fitmask,'INST_PC1_SD'].std(ddof=1)-1)<1e-10
    assert (vec[:,0]>0).all(), 'Unexpected PCA direction; inspect rather than reverse for effect'
    income_sheet = openpyxl.load_workbook(ROOT/'01_data/raw/wdi/historical_income_classification.xlsx',
                                        read_only=True,data_only=True)['Country Analytical History']
    rows = list(income_sheet.iter_rows(values_only=True))
    index = list(rows[5]).index(2020)
    assert rows[4][index]=='FY22'
    incomes = {row[0]:row[index] for row in rows[6:] if row[0]}
    panel['income_FY22'] = panel.iso3.map(incomes)
    panel['income_group'] = panel.income_FY22.map({'H':'high','UM':'middle','LM':'middle','L':'low'})
    discrepancies = pd.read_csv(ROOT/'04_results/tables/ICRG_supplied_audit/A_subcomponent_discrepancies.csv')
    issues = discrepancies.merge(cross[['country_icrg','iso3']],on='country_icrg',validate='many_to_one')
    issue_keys = set(zip(issues.iso3,issues.year))
    panel['ICRG_A_subcomponent_discrepancy'] = [(iso,year) in issue_keys for iso,year in zip(panel.iso3,panel.year)]
    out = ROOT/'04_results/tables/full_reconstruction';out.mkdir(parents=True,exist_ok=True)
    mapping.merge(locations,on='location_id',how='left',validate='many_to_one').to_csv(
        out/'ICRG_GBD2021_country_crosswalk.csv',index=False,encoding='utf-8-sig')
    pd.DataFrame({'component':components,'mean':mean,'sample_SD':sd,'PC1_eigenvector':vec[:,0],
                  'PC1_correlation_loading':vec[:,0]*np.sqrt(eig[0])}).to_csv(out/'PCA_loadings.csv',index=False,encoding='utf-8-sig')
    pd.DataFrame({'PC':range(1,6),'eigenvalue':eig,'variance_fraction':eig/eig.sum()}).to_csv(
        out/'PCA_explained_variance.csv',index=False,encoding='utf-8-sig')
    panel.to_csv(ROOT/'01_data/processed/full_reconstruction_panel_GBD2021_ICRG2024.csv',index=False,encoding='utf-8-sig')
    panel.loc[fitmask,['iso3','year',*components,'INST_PC1_SD']].to_csv(
        ROOT/'01_data/processed/PCA_fitting_sample.csv',index=False,encoding='utf-8-sig')
    report = {'spec_sha256':hashlib.sha256(specpath.read_bytes()).hexdigest(),
              'PCA_N':int(fitmask.sum()),'PCA_countries':int(panel.loc[fitmask,'iso3'].nunique()),
              'GBD_mapped_countries':len(mapped),'outside_GBD_country_list':sorted(absent),
              'variance_PC1':float(eig[0]/eig.sum()),'PC1_eigenvectors':vec[:,0].tolist(),
              'complete_primary_N':int(panel[['MD_AS',*spec['covariates']]].notna().all(axis=1).sum()),
              'imputed_cells':0,'models_fitted':False}
    (ROOT/'03_logs/full_panel_and_PCA.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(report,ensure_ascii=True,indent=2))


if __name__=='__main__':main()
