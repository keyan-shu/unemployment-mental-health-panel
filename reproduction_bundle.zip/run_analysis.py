"""Rebuild the revised analysis from user-supplied raw inputs and verify outputs."""
from pathlib import Path
import argparse, hashlib, json, os, subprocess, sys

ROOT=Path(__file__).resolve().parent
STEPS=['04_prepare_candidate_covariates.py','11_audit_GBD2021_download.py',
       '13_audit_supplied_ICRG.py','14_build_full_reconstruction_panel.py',
       '15_run_full_FE_reconstruction.py','16_run_declared_GMM.py',
       '17_run_reviewer_sensitivities.py']

def check_inputs():
    issues=[]
    for entry in json.loads((ROOT/'required_inputs.json').read_text(encoding='utf-8')):
        path=ROOT/entry['path']
        if not path.is_file():issues.append('Missing: '+entry['path'])
        elif hashlib.sha256(path.read_bytes()).hexdigest()!=entry['sha256']:
            issues.append('Different source vintage/content: '+entry['path'])
    return issues

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--check-inputs',action='store_true')
    p.add_argument('--verify-only',action='store_true')
    args=p.parse_args()
    if not args.verify_only:
        issues=check_inputs()
        if issues:
            print('\n'.join(issues));print('See DATA_SOURCES.md. No model was fitted.')
            return 2
        print('All 14 required source files match the recorded hashes.',flush=True)
        if args.check_inputs:return 0
        env=dict(os.environ,OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',PYTHONIOENCODING='utf-8')
        for step in STEPS:
            print('Running '+step,flush=True)
            subprocess.run([sys.executable,'-X','utf8',str(ROOT/'02_code'/step)],cwd=ROOT,env=env,check=True)
        subprocess.run([sys.executable,str(ROOT/'export_appendix_details.py')],cwd=ROOT,env=env,check=True)
    subprocess.run([sys.executable,str(ROOT/'validation/verify_outputs.py')],cwd=ROOT,check=True)
    return 0

if __name__=='__main__':raise SystemExit(main())
