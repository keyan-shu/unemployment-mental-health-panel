"""Download only the WDI and KOF files used by the final analysis; preserve caches."""
from pathlib import Path
from urllib.request import Request, urlopen
import json

ROOT=Path(__file__).resolve().parent
jobs=[('wdi/countries_current.json','https://api.worldbank.org/v2/country?format=json&per_page=400'),
      ('kof/KOFGI_2025_public.xlsx','https://ethz.ch/content/dam/ethz/special-interest/dual/kof-dam/documents/Globalization/2025/KOFGI_2025_public.xlsx')]
for code in ['SL.UEM.TOTL.ZS','SL.UEM.TOTL.NE.ZS','SP.URB.TOTL.IN.ZS','SE.PRM.UNER.ZS','NY.GDP.PCAP.KD.ZG','NY.GDP.PCAP.KD','SH.XPD.CHEX.GD.ZS']:
    jobs.append((f'wdi/{code}_1996_2020.json',f'https://api.worldbank.org/v2/country/all/indicator/{code}?date=1996:2020&format=json&per_page=20000&source=2'))
if __name__=='__main__':
    for name,url in jobs:
        path=ROOT/'01_data/raw'/name
        if path.exists():print('Preserved '+name);continue
        with urlopen(Request(url,headers={'User-Agent':'Panel-replication/1.0'}),timeout=60) as response:data=response.read()
        if name.endswith('.json'):json.loads(data)
        else:assert data.startswith(b'PK'),'Expected XLSX'
        path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(data);print('Downloaded '+name)
    print('Obtain the historical income workbook, GBD ZIP and ICRG files separately. Check hashes before fitting.')
